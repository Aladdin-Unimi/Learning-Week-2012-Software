function main( input ) {
	
	/* scrivi il tuo codice tra la precedente e la successiva parentesi graffa */
	
	
}