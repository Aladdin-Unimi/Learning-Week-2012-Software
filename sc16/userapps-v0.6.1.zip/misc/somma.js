function main( input ) {
	output( parseInt(input.i0) + parseInt(input.i1) );
	output( input.s0 + input.s1 );
}
