function main( input ) {
	var p = [ input.lat, input.lng ];
	marker( p );
}
