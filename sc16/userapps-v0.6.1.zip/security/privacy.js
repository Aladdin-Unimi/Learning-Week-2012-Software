var x = 0.0;
var y = 0.0;

function  main(input){
  output("Le coordinate più probabili del punto: " + x + "," + y);
}