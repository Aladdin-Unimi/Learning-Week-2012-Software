function checkpwd(input){
  if (input.pwd == "pippo")
    return true;
  return false;
}
